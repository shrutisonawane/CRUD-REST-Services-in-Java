/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myrestservice;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
//import javax.xml.bind.annotation.XmlAttribute;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "Student")
@XmlAccessorType(XmlAccessType.FIELD)
public class Student 
{
    @XmlElement(name = "id")      
    private String id;
    
    @XmlElement(name = "name")      
    private String name;
    
    @XmlElement(name = "GradeBookItem")
    private List<GradeBookItem> gradeBookItems;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the gradeBookItems
     */
    public List<GradeBookItem> getGradeBookItems() {
        return gradeBookItems;
    }

    /**
     * @param gradeBookItems the gradeBookItems to set
     */
    public void setGradeBookItems(List<GradeBookItem> gradeBookItems) {
        this.gradeBookItems = gradeBookItems;
    }
    
    
}
