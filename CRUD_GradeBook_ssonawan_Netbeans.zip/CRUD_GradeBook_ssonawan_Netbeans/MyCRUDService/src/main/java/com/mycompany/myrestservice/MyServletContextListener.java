/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myrestservice;
import java.io.File;
//import java.util.Collections;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import java.util.HashMap;
import javax.servlet.annotation.WebListener;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Unmarshaller;
/**
 *
 * @author Shruti Sonawane
 */
@WebListener
public class MyServletContextListener implements ServletContextListener 
{
    //String filePath = "C:\\Users\\Shruti Sonawane\\Documents\\NetBeansProjects\\MyCRUDService\\GradeBook.xml";
    static GradeBook gradeBookData;
    
    @Override
    public void contextDestroyed(ServletContextEvent arg0) 
    {
	System.out.println("ServletContextListener destroyed");
    }
    
    @Override
    public void contextInitialized(ServletContextEvent arg0) 
    {
        int maxGradeBookItemID=0;
        int maxStudentID = 0;
        
        HashMap<String,Student> StudentCollection = new HashMap<>();
       // HashMap<String,GradeBook> GradeBookCollection = new HashMap<>();
        
        try
        {
           String filePath = arg0.getServletContext().getRealPath("/")+"WEB-INF"+"\\GradeBook.xml";
           System.out.println("relative path "+filePath);
           JAXBContext jaxbContext = JAXBContext.newInstance(GradeBook.class);
           Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
           gradeBookData = (GradeBook) jaxbUnmarshaller.unmarshal(new File(filePath)); 
            // gradeBookData = (GradeBook)XMLConverter.convertFromXmlToObject(this, GradeBook.class);
            //System.out.println("Student size"+gradeBookData.getStudentList().size());
               for(Student stu:gradeBookData.getStudentList())
               {
                   StudentCollection.put(stu.getId(),stu);
                   System.out.println(stu.getName());
                   if(Integer.parseInt(stu.getId())> maxStudentID)
                   maxStudentID = Integer.parseInt(stu.getId());
                   for(GradeBookItem gb:stu.getGradeBookItems())
                   {
                       if(Integer.parseInt(gb.getId())>maxGradeBookItemID)
                           maxGradeBookItemID=Integer.parseInt(gb.getId());
                   }
               }
           // }

    //       arg0.getServletContext().setAttribute("gradeBookCollection", gradeBookData);
           arg0.getServletContext().setAttribute("maxGradeBookItemID", maxGradeBookItemID);
           arg0.getServletContext().setAttribute("studentCollection", StudentCollection);
           arg0.getServletContext().setAttribute("maxStudentID", maxStudentID);
           arg0.getServletContext().setAttribute("gradeBookData", gradeBookData);
           
        }
        catch(Exception e)
        {
            e.printStackTrace();
            System.out.println("Exception is: "+e);
        }      
    }
}
