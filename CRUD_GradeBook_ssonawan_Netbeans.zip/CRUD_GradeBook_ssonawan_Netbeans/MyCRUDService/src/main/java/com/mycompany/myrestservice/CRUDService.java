package com.mycompany.myrestservice;

import java.util.HashMap;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * REST Web Service
 *
 * @author Shruti Sonawane
 */
@Path("GradeBook")
public class CRUDService extends HttpServlet
{    /**
     * Creates a new instance of CRUDService
     */
    @Context
    private UriInfo context;
    
    public HashMap<String,Student> studentCollection = new HashMap<>();
    public HashMap<String,GradeBook> gradeBookCollection = new HashMap<String,GradeBook>();
    
    //Creating a new student
    private static Student newStud;
    
    //Creating a new student
    @POST
    @Path("/{gradeBookID}/Student")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public Response createStudent(@PathParam("gradeBookID") String gradeBookID, String content,@Context HttpServletRequest request) 
    {
        Response myResponse=null;
        studentCollection = (HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
        GradeBook gb = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
        gradeBookCollection.put(gb.getId(),gb);
             
         try
         {            
            if(!gradeBookCollection.containsKey(gradeBookID))
            {
                myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }
            else
            {
            int maxStudentID = (int)request.getServletContext().getAttribute("maxStudentID");
            newStud = (Student) XMLConverter.convertFromXmlToObject(content, Student.class);
            
            if(studentCollection.containsKey(maxStudentID++))
            {
               myResponse = Response.status(Response.Status.CONFLICT).entity("Student already exists").build();
            }
            else
            {
                Student s = new Student();
                maxStudentID++;
                s.setId(Integer.toString(maxStudentID));
                
                s.setName(newStud.getName());
                s.setGradeBookItems(newStud.getGradeBookItems());
                studentCollection.put(s.getId(),s);
                int id = maxStudentID;
                
                URI locationURI = URI.create(context.getAbsolutePath() + "/"+gradeBookID+"/Student/" + Integer.toString(id));
                String xmlResp = XMLConverter.convertFromObjectToXml(s, Student.class);                
                myResponse = Response.status(Response.Status.CREATED).location(locationURI).entity(s.getId()).build();
                
            }
            }
         }
        catch(Exception ex)
        {
            System.out.println(ex);
             myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();
        }
       
        return myResponse;
    }
         
    //Getting an existing student
    @GET
    @Path("/{gradeBookID}/Student/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public Response getStudentFromCollection(@PathParam("gradeBookID") String gradeBookID, @PathParam("id") String studentID, @Context HttpServletRequest request) 
    {
        Response myResponse;
        try
        {
           
        studentCollection = (HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
        GradeBook gb = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
        gradeBookCollection.put(gb.getId(),gb);
        
        if(!gradeBookCollection.containsKey(gradeBookID))
        {
            myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
        }
        else if(!studentCollection.containsKey(studentID))
        {
            myResponse = Response.status(Response.Status.GONE).entity("Student does not exist").build();
        }
        else
        {
            Student resp = studentCollection.get(studentID);
            String xmlString = XMLConverter.convertFromObjectToXml(resp, Student.class);
            //returning the student info
            URI locationURI = URI.create(context.getAbsolutePath() + "/"+gradeBookID+"/Student/" + studentID);
            myResponse = Response.status(Response.Status.OK).location(locationURI).entity(xmlString).build();
         }
        }
        catch(Exception ex)
        {
            System.out.println(ex);
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();
        }
        return myResponse;
    }
    
    //Updating student 
    @PUT
    @Path("/{gradeBookID}/Student/{id}")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public Response updateStudent(@PathParam("gradeBookID") String gradeBookID, @PathParam("id") String studentID, String content, @Context HttpServletRequest request)
    {
        Response myResponse;
        try
        {
           studentCollection = (HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
           
           GradeBook gb = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
           gradeBookCollection.put(gb.getId(),gb);
           
           Student studUpdate = (Student)XMLConverter.convertFromXmlToObject(content, Student.class);
           if(!gradeBookCollection.containsKey(gradeBookID))
            {
               myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }
           else if(!studentCollection.containsKey(studentID))
           {
                myResponse = Response.status(Response.Status.NOT_FOUND).entity("Student ID not found").build();
           }
           else
           {
               Student s= studentCollection.get(studentID);
               s.setName(studUpdate.getName());
               studentCollection.put(s.getId(), s);
               String xmlString = XMLConverter.convertFromObjectToXml(s, Student.class);
               URI locationURI = URI.create(context.getAbsolutePath() + "/"+gradeBookID+"/Student/" + studentID);
               myResponse = Response.status(Response.Status.OK).location(locationURI).entity(s).build();
           }
        }
        catch(Exception ex)
        {
            System.out.println(ex);
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();
        }
        return myResponse;       
    }  
      
    //Deleting a student
    @DELETE
    @Path("/{gradeBookID}/Student/{id}")
    @Produces(MediaType.APPLICATION_XML)
    public Response deleteStudent(@PathParam("gradeBookID") String gradeBookID, @PathParam("id") String id, @Context HttpServletRequest request)
    {
       Response myResponse;
        try
        {
            studentCollection = (HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
            
            GradeBook gb = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
            gradeBookCollection.put(gb.getId(),gb);
            
        if(!gradeBookCollection.containsKey(gradeBookID))
            {
               myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }    
        else if(!studentCollection.containsKey(id))
        {
            myResponse = Response.status(Response.Status.GONE).entity("Student ID not found").build();     
        }
        else
        {
            studentCollection.remove(id);
            myResponse = Response.status(Response.Status.OK).entity("Student deleted").build();   
        }
        }
        catch(Exception ex)
        {
           ex.printStackTrace();
           myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();           
        }
        
        return myResponse;
    }
    //******************************************************************************************************************
    
    //Creating a gradebookitem
    @POST
    @Path("/{gradeBookID}/Student/{studID}/GradeBookItem")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public Response createGradeBookItem(@PathParam("gradeBookID") String gradeBookID, @PathParam("studID") String studID, String content,@Context HttpServletRequest request) 
    {
        Response myResponse=null;
        try
        {
            studentCollection = (HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
             
             GradeBook gb = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
             gradeBookCollection.put(gb.getId(),gb);
        if(!gradeBookCollection.containsKey(gradeBookID))
            {
                myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }  
        else if(!studentCollection.containsKey(studID))
        {
             myResponse = Response.status(Response.Status.NOT_FOUND).entity("Student ID not found").build(); 
        }
        else
        {
            int maxGradeBookItemID=0;
            maxGradeBookItemID= (int)request.getServletContext().getAttribute("maxGradeBookItemID");
            maxGradeBookItemID++;
            
            GradeBookItem gbi = new GradeBookItem();
            gbi = (GradeBookItem)XMLConverter.convertFromXmlToObject(content,GradeBookItem.class);
            gbi.setId(String.valueOf(maxGradeBookItemID));
            System.out.println("new GBI id: "+gbi.getId());
            Student s= studentCollection.get(studID);
            if(s.getGradeBookItems()==null)
            {
                List<GradeBookItem> gradeItems = new ArrayList<GradeBookItem>();
                gradeItems.add(gbi);
                s.setGradeBookItems(gradeItems);
            }
            else
            {
                s.getGradeBookItems().add(gbi);
            }
            studentCollection.put(s.getId(), s);
            
            URI locationURI = URI.create(context.getAbsolutePath() + "/"+gradeBookID+"/Student/" + String.valueOf(studID)+"/GradeBookItem/"+String.valueOf(gbi.getId()));
            String xmlResp = XMLConverter.convertFromObjectToXml(s, Student.class);
            myResponse = Response.status(Response.Status.CREATED).location(locationURI).entity(gbi.getId()).build();
        } 
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();  
        }
        return myResponse;
    }
    
    //Getting a gradebook item
    @GET
    @Path("/{gradeBookID}/Student/{studID}/GradeBookItem/{gbid}")
    @Produces(MediaType.APPLICATION_XML)
    public Response getGradeBookItemFromCollection(@PathParam("gradeBookID") String gradeBookID, @PathParam("studID") String studID, @PathParam("gbid") String gbid, @Context HttpServletRequest request) 
    {
        Response myResponse=null;
        try
        {
           studentCollection = (HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
           
           GradeBook gb = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
           gradeBookCollection.put(gb.getId(),gb);
           
           GradeBookItem ret=null;
           if(!gradeBookCollection.containsKey(gradeBookID))
            {
               myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }
           else if(!studentCollection.containsKey(studID))
           {
               myResponse = Response.status(Response.Status.NOT_FOUND).entity("Student ID not found").build(); 
           }
           else
           {
               Student s= studentCollection.get(studID);
               for(GradeBookItem g:s.getGradeBookItems())
               {
                   if(g.getId().equals(gbid))
                   {
                       ret = g;
                       String xmlString = XMLConverter.convertFromObjectToXml(ret, Student.class);
                       URI locationURI = URI.create(context.getAbsolutePath() + "/"+gradeBookID+"/Student/" + studID+"/GradeBookItem/"+gbid);
                       myResponse = Response.status(Response.Status.OK).location(locationURI).entity(xmlString).build();
                       break;
                   }
                   else
                   {
                       myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook Item ID not found").build(); 
                   }
               }
                             
           }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();  
        }
        return myResponse; 
    }
    
    //Updating a gradeBookItem
    @PUT
    @Path("/{gradeBookID}/Student/{stuid}/GradeBookItem/{gbid}")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public Response updateGradeBookItem(@PathParam("gradeBookID") String gradeBookID, @PathParam("stuid") String stuid,@PathParam("gbid") String gbid, String content, @Context HttpServletRequest request)
    {
        Response myResponse;
        try
        {
            studentCollection=(HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
            
            GradeBook gradeB = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
            gradeBookCollection.put(gradeB.getId(),gradeB);
          
            if(!gradeBookCollection.containsKey(gradeBookID))
            {
               myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }
            else if(!studentCollection.containsKey(stuid))
        {
            myResponse = Response.status(Response.Status.NOT_FOUND).entity("Student ID not found").build(); 
        }
        else
        {
            System.out.println("inside PUT");
            GradeBookItem gb = (GradeBookItem)XMLConverter.convertFromXmlToObject(content, GradeBookItem.class);
            Student s=studentCollection.get(stuid);
            GradeBookItem ret= new GradeBookItem();
            for(GradeBookItem g:s.getGradeBookItems())
            {
                if(g.getId().equals(gbid))
                {
                    g.setAppeal(gb.getAppeal());
                    g.setFeedback(gb.getFeedback());
                    g.setGrade(gb.getGrade());
                    g.setName(gb.getName());
                    ret=g;
                    break;
                }
            }
            studentCollection.put(stuid, s);
            String xmlString = XMLConverter.convertFromObjectToXml(s, Student.class);
            URI locationURI = URI.create(context.getAbsolutePath() + "/"+gradeBookID+"/Student/" + stuid+"/GradeBookItem/"+gbid);
            //System.out.println("URI location: "+locationURI);
            myResponse = Response.status(Response.Status.OK).location(locationURI).entity(ret).build();
         }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();  
        }
        return myResponse;      
    }   
    
    //deleting a gradebook item
    @DELETE
    @Path("/{gradeBookID}/Student/{stuid}/GradeBookItem/{gbid}")
    @Produces(MediaType.APPLICATION_XML)
    public Response deleteResource(@PathParam("gradeBookID") String gradeBookID, @PathParam("stuid") String stuid, @PathParam("gbid") String gbid, @Context HttpServletRequest request)
    {
       Response myResponse=null;
        try
        {
            studentCollection = (HashMap<String,Student>)request.getServletContext().getAttribute("studentCollection");
            
            GradeBook gradeB = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
            gradeBookCollection.put(gradeB.getId(),gradeB);
            
             if(!gradeBookCollection.containsKey(gradeBookID))
            {
               myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }
             else if(!studentCollection.containsKey(stuid))
            {
                 myResponse = Response.status(Response.Status.NOT_FOUND).entity("Student ID not found").build(); 
            }
            else
            {
                Student s= studentCollection.get(stuid);
                for(GradeBookItem g:s.getGradeBookItems())
                {
                    if(g.getId().equals(gbid))
                    {
                        s.getGradeBookItems().remove(g);
                        myResponse = Response.status(Response.Status.OK).entity("GradeBook item deleted").build();
                        break;
                    }
                    else
                    {
                        myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook Item ID not found").build();
                    }
                }
                
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();  
        }
        return myResponse;
    }
    
    //Creating a new gradebook
    @POST
    @Path("")
    @Consumes(MediaType.APPLICATION_XML)
    @Produces(MediaType.APPLICATION_XML)
    public Response createGradeBook(String content,@Context HttpServletRequest request) 
    {
        Response myResponse;
        
        GradeBook gradeB = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
        gradeBookCollection.put(gradeB.getId(),gradeB);
            
        try
        {
             GradeBook newGB = (GradeBook)XMLConverter.convertFromXmlToObject(content, GradeBook.class);
             if(gradeBookCollection.containsKey(newGB.getId()))
             {
                myResponse = Response.status(Response.Status.CONFLICT).entity("GradeBook already exists").build(); 
             }
             else
             {
                 gradeBookCollection.put(newGB.getId(), newGB);
                 URI locationURI = URI.create(context.getAbsolutePath() + "/"+newGB.getId());
                //String xmlResp = XMLConverter.convertFromObjectToXml(newGB, Student.class); 
                System.out.println("new GB: "+newGB.getId());
                 myResponse = Response.status(Response.Status.CREATED).location(locationURI).entity("New gradebook created!").build();
             }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();  
        }
       return myResponse;        
    }
    
    //Getting a gradebook
    @GET
    @Path("/{gradeBookID}")
    @Produces(MediaType.APPLICATION_XML)
    public Response getGradeBookItemFromCollection(@PathParam("gradeBookID") String gradeBookID, @Context HttpServletRequest request) 
    {
        Response myResponse=null;
        GradeBook gradeB = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
        gradeBookCollection.put(gradeB.getId(),gradeB);
            
        try
        {
            if(!gradeBookCollection.containsKey(gradeBookID))
            {
                myResponse = Response.status(Response.Status.NOT_FOUND).entity("Gradebook does not exist").build();  
            }
            else
            {
                GradeBook gbook = gradeBookCollection.get(gradeBookID);
                myResponse = Response.status(Response.Status.OK).entity(gbook).build();  
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();  
        }
        return myResponse;
    }
    
    //deleting a gradebook 
    @DELETE
    @Path("/{gradeBookID}")
    @Produces(MediaType.APPLICATION_XML)
    public Response deleteGradeBook(@PathParam("gradeBookID") String gradeBookID, @Context HttpServletRequest request)
    {
       Response myResponse=null;
        try
        {
            GradeBook gradeB = (GradeBook)request.getServletContext().getAttribute("gradeBookData");
            gradeBookCollection.put(gradeB.getId(),gradeB);
            
             if(!gradeBookCollection.containsKey(gradeBookID))
            {
               myResponse = Response.status(Response.Status.NOT_FOUND).entity("GradeBook ID not found").build(); 
            }
            else
            {  
                gradeBookCollection.remove(gradeBookID);
                myResponse = Response.status(Response.Status.OK).entity("GradeBook deleted").build();              
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
            myResponse = Response.status(Response.Status.BAD_REQUEST).entity("Something was not right..").build();  
        }
        return myResponse;
    }
    
 }

  
