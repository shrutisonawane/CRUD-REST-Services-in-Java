/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.myrestservice;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "Gradebooks") //, xmlns="http://www.asu.edu/GradeBook")
@XmlAccessorType(XmlAccessType.FIELD)
public class AllGradeBooks 
{
    @XmlElement(name = "Institute")      
    private String institute;
    
    @XmlElement(name = "GradeBook")
    private List<GradeBook> GradeBookList;

    /**
     * @return the institute
     */
    public String getInstitute() {
        return institute;
    }

    /**
     * @param institute the institute to set
     */
    public void setInstitute(String institute) {
        this.institute = institute;
    }

    /**
     * @return the GradeBookList
     */
    public List<GradeBook> getGradeBookList() {
        return GradeBookList;
    }

    /**
     * @param GradeBookList the GradeBookList to set
     */
    public void setGradeBookList(List<GradeBook> GradeBookList) {
        this.GradeBookList = GradeBookList;
    }
}
