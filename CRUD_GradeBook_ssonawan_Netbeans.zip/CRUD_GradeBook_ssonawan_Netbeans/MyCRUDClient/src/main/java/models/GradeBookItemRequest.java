/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package models;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Shruti Sonawane
 */
@XmlRootElement(name = "GradeBookItem")
@XmlAccessorType(XmlAccessType.FIELD)
public class GradeBookItemRequest 
{
    @XmlElement(name = "itemID")
    private String id;
    
    @XmlElement(name = "itemName")
    private String name;
    
    @XmlElement(name = "itemGrade")
    private String grade;
    
    @XmlElement(name = "hasAppealed")
    private Boolean appeal;
    
    @XmlElement(name = "itemFeedback")
    private String feedback;

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the grade
     */
    public String getGrade() {
        return grade;
    }

    /**
     * @param grade the grade to set
     */
    public void setGrade(String grade) {
        this.grade = grade;
    }

    /**
     * @return the appeal
     */
    public Boolean getAppeal() {
        return appeal;
    }

    /**
     * @param appeal the appeal to set
     */
    public void setAppeal(Boolean appeal) {
        this.appeal = appeal;
    }

    /**
     * @return the feedback
     */
    public String getFeedback() {
        return feedback;
    }

    /**
     * @param feedback the feedback to set
     */
    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

}
