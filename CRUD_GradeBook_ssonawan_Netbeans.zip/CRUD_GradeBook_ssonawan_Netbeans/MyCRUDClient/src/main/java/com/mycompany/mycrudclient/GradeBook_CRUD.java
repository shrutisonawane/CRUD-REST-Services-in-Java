/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.mycrudclient;
import models.*;
import utils.XMLConverter;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.UniformInterfaceException;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.api.client.config.ClientConfig;
import com.sun.jersey.api.client.config.DefaultClientConfig;
import javax.ws.rs.core.MediaType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
/**
 *
 * @author Shruti Sonawane
 */
public class GradeBook_CRUD 
{
    private WebResource webResource;
    private Client client;
    private static final String BASE_URI = "http://localhost:8080/MyCRUDService/webresources";
    private static final Logger LOG = LoggerFactory.getLogger(GradeBook_CRUD.class);
    
     public GradeBook_CRUD() 
     {        
        ClientConfig config = new DefaultClientConfig();
         client = Client.create(config);
        webResource = client.resource(BASE_URI).path("GradeBook");
     }
     
     //creating a new student
     public ClientResponse createStudent(String gradeBookID,StudentRequest newStud) throws UniformInterfaceException 
     {
         LOG.info("Initiating the create student request");
         String stud = XMLConverter.convertFromObjectToXml(newStud, StudentRequest.class);
         return webResource.path(gradeBookID+"/Student").type(MediaType.APPLICATION_XML).post(ClientResponse.class, stud);
     }
     
     //deleting a student
      public ClientResponse deleteStudent(String gradeBookID,String studentID) throws UniformInterfaceException 
      {
          LOG.info("Initiating the delete student request");
          return webResource.path(gradeBookID+"/Student/"+studentID).delete(ClientResponse.class);
      }

      //updating student info
     public ClientResponse updateStudent(String gradeBookID, String studentID, StudentRequest updatedStud) throws UniformInterfaceException 
     {
         LOG.info("Initiating the update student request");
         String stud = XMLConverter.convertFromObjectToXml(updatedStud, StudentRequest.class);
        return webResource.path(gradeBookID+"/Student/"+studentID).type(MediaType.APPLICATION_XML).put(ClientResponse.class, stud);
     }
     
     //get student method
      public ClientResponse retrieveStudent(String gradeBookID, String studentID) throws UniformInterfaceException 
      {
          LOG.info("Initiating the get student request");
          return webResource.path(gradeBookID+"/Student/"+studentID).accept(MediaType.APPLICATION_XML).get(ClientResponse.class);
      }   
//**********************************************************************************************************************
      
     //creating new grade book item
     public ClientResponse createGradeBookItem(String gradeBookID, String studentID, GradeBookItemRequest gbir) throws UniformInterfaceException 
     {
         LOG.info("Initiating the create gradebook item request");
         String gbi = XMLConverter.convertFromObjectToXml(gbir, GradeBookItemRequest.class);
         return webResource.path(gradeBookID+"/Student/"+studentID+"/GradeBookItem").type(MediaType.APPLICATION_XML).post(ClientResponse.class, gbi);
     }
     
      public ClientResponse deleteGradeBookItem(String gradeBookID, String studentID, String gradeBookItemID) throws UniformInterfaceException 
      {
          LOG.info("Initiating the delete gradebook item request");
          return webResource.path(gradeBookID+"/Student/"+studentID+"/GradeBookItem/"+gradeBookItemID).delete(ClientResponse.class);
      }

     public ClientResponse updateGradeBookItem(String gradeBookID, String studentID, String gradeBookItemID, GradeBookItemRequest gbir) throws UniformInterfaceException 
     {
         LOG.info("Initiating the update gradebook item request");
         String gbi = XMLConverter.convertFromObjectToXml(gbir, GradeBookItemRequest.class);
        return webResource.path(gradeBookID+"/Student/"+studentID+"/GradeBookItem/"+gradeBookItemID).type(MediaType.APPLICATION_XML).put(ClientResponse.class, gbi);
     }
     
     //get GradeBookItem method
     public ClientResponse retrieveGradeBookItem(String gradeBookID, String studentID, String gradeBookItemID) throws UniformInterfaceException 
      {
          LOG.info("Initiating the get gradebook item request");
          return webResource.path(gradeBookID+"/Student/"+studentID+"/GradeBookItem/"+gradeBookItemID).accept(MediaType.APPLICATION_XML).get(ClientResponse.class);
      }  
         
//********************************************************************************************************************
     
     //create new gradebook
     public ClientResponse createGradeBook(GradeBookRequest gbID) throws UniformInterfaceException 
     {
         String gbstr = XMLConverter.convertFromObjectToXml(gbID, GradeBookRequest.class);
        return webResource.path("").type(MediaType.APPLICATION_XML).post(ClientResponse.class, gbstr);
     }

      public ClientResponse deleteGradeBook(GradeBookRequest gbID) throws UniformInterfaceException 
      {
        String gbstr = XMLConverter.convertFromObjectToXml(gbID, GradeBookRequest.class);
        return webResource.path("/"+gbID.getId()).type(MediaType.APPLICATION_XML).post(ClientResponse.class, gbstr);
      }
         
     public void close() 
     { 
        client.destroy();
     }
}
